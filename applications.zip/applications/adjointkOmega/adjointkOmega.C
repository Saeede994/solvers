/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | Copyright (C) 2011-2013 OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

\*---------------------------------------------------------------------------*/

#include "adjointkOmega.H"
#include "addToRunTimeSelectionTable.H"

#include "backwardsCompatibilityWallFunctions.H"

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

namespace Foam
{
namespace incompressible
{
namespace RASModels
{

// * * * * * * * * * * * * * * Static Data Members * * * * * * * * * * * * * //

defineTypeNameAndDebug(adjointkOmega, 0);
addToRunTimeSelectionTable(RASModel, adjointkOmega, dictionary);

// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

adjointkOmega::adjointkOmega
(
    const volVectorField& U,
    const surfaceScalarField& phi,
    transportModel& transport,
    const word& turbulenceModelName,
    const word& modelName
)
:
    RASModel(modelName, U, phi, transport, turbulenceModelName),

    Cmu_
    (
        dimensioned<scalar>::lookupOrAddToDict
        (
            "betaStar",
            coeffDict_,
            0.09
        )
    ),
    beta_
    (
        dimensioned<scalar>::lookupOrAddToDict
        (
            "beta",
            coeffDict_,
            0.072
        )
    ),
    alpha_
    (
        dimensioned<scalar>::lookupOrAddToDict
        (
            "alpha",
            coeffDict_,
            0.52
        )
    ),
    alphaK_
    (
        dimensioned<scalar>::lookupOrAddToDict
        (
            "alphaK",
            coeffDict_,
            0.5
        )
    ),
    alphaOmega_
    (
        dimensioned<scalar>::lookupOrAddToDict
        (
            "alphaOmega",
            coeffDict_,
            0.5
        )
    ),

    k_
    (
        IOobject
        (
            "k",
            runTime_.timeName(),
            mesh_,
            IOobject::MUST_READ,
            IOobject::AUTO_WRITE
        ),
        mesh_
    ),
    k_a_
    (
        IOobject
        (
            "k_a",
            runTime_.timeName(),
            mesh_,
            IOobject::NO_READ,
            IOobject::AUTO_WRITE
        ),
        autoCreateK("k_a", mesh_)
    ),
    omega_
    (
        IOobject
        (
            "omega",
            runTime_.timeName(),
            mesh_,
            IOobject::MUST_READ,
            IOobject::AUTO_WRITE
        ),
        mesh_
    ),
    omega_a_
    (
        IOobject
        (
            "omega_a",
            runTime_.timeName(),
            mesh_,
            IOobject::NO_READ,
            IOobject::AUTO_WRITE
        ),
        autoCreateOmega("omega_a", mesh_)
    ),
    nut_
    (
        IOobject
        (
            "nut",
            runTime_.timeName(),
            mesh_,
            IOobject::MUST_READ,
            IOobject::AUTO_WRITE
        ),
        mesh_
    ),
    U_a_
    (
        IOobject
        (
            "U_a",
            runTime_.timeName(),
            mesh_,
            IOobject::MUST_READ,
            IOobject::AUTO_WRITE
        ),
        mesh_
    ),
    phi_a_
    (
        IOobject
        (
            "phi_a",
            runTime_.timeName(),
            mesh_,
            IOobject::READ_IF_PRESENT,
            IOobject::AUTO_WRITE
        ),
        linearInterpolate(U_a_) & mesh_.Sf()
    ),
    kMin_a_
    (
	"kMin_a_",
        dimensionSet(0,0,0,0,0,0,0),
	0.0000001
    ),
    omegaMin_a_
    (
	"omegaMin_a_",
        dimensionSet(0,2,-1,0,0,0,0),
	0.0000001
    ),
    S1_c
    (
        IOobject
        (
            "S1_c",
            runTime_.timeName(),
            mesh_,
            IOobject::READ_IF_PRESENT,
            IOobject::AUTO_WRITE
        ),
        mesh_
    ),
    S1_d
    (
        IOobject
        (
            "S1_d",
            runTime_.timeName(),
            mesh_,
            IOobject::READ_IF_PRESENT,
            IOobject::AUTO_WRITE
        ),
        mesh_
    ),
    S2_c
    (
        IOobject
        (
            "S2_c",
            runTime_.timeName(),
            mesh_,
            IOobject::READ_IF_PRESENT,
            IOobject::AUTO_WRITE
        ),
        mesh_
    ),
    S2_d
    (
        IOobject
        (
            "S2_d",
            runTime_.timeName(),
            mesh_,
            IOobject::READ_IF_PRESENT,
            IOobject::AUTO_WRITE
        ),
        mesh_
    ),
    Par1
    (
        IOobject
        (
            "Par1",
            runTime_.timeName(),
            mesh_,
            IOobject::READ_IF_PRESENT,
            IOobject::AUTO_WRITE
        ),
        mesh_
    ),
    Par2
    (
        IOobject
        (
            "Par2",
            runTime_.timeName(),
            mesh_,
            IOobject::READ_IF_PRESENT,
            IOobject::AUTO_WRITE
        ),
        mesh_
    ),
    Par3
    (
        IOobject
        (
            "Par3",
            runTime_.timeName(),
            mesh_,
            IOobject::READ_IF_PRESENT,
            IOobject::AUTO_WRITE
        ),
        mesh_
    )
{
    //bound(k_a_, kMin_a_);
    //bound(omega_a_, omegaMin_a_);

    //nut_ = k_/omega_;
    //nut_.correctBoundaryConditions();

    printCoeffs();
}


// * * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * //

tmp<volSymmTensorField> adjointkOmega::R() const
{
    return tmp<volSymmTensorField>
    (
        new volSymmTensorField
        (
            IOobject
            (
                "R",
                runTime_.timeName(),
                mesh_,
                IOobject::NO_READ,
                IOobject::NO_WRITE
            ),
            ((2.0/3.0)*I)*k_ - nut_*twoSymm(fvc::grad(U_)),
            k_.boundaryField().types()
        )
    );
}


tmp<volSymmTensorField> adjointkOmega::devReff() const
{
    return tmp<volSymmTensorField>
    (
        new volSymmTensorField
        (
            IOobject
            (
                "devRhoReff",
                runTime_.timeName(),
                mesh_,
                IOobject::NO_READ,
                IOobject::NO_WRITE
            ),
           -nuEff()*dev(twoSymm(fvc::grad(U_)))
        )
    );
}


tmp<fvVectorMatrix> adjointkOmega::divDevReff(volVectorField& U_a) const
{
    volTensorField gradU = fvc::grad(U_);
    volVectorField gradK = fvc::grad(k_);
    volVectorField gradOmega = fvc::grad(omega_);
    volVectorField gradK_a = fvc::grad(k_a_);
    volVectorField gradOmega_a = fvc::grad(omega_a_);
    volSymmTensorField S = symm(gradU);
    volScalarField SS = magSqr(S);
    return
    (
      - fvm::laplacian(nuEff(), U_a)
      - fvc::div(nuEff()*dev(T(fvc::grad(U_a))))
      + gradK*k_a_
      + gradOmega*omega_a_
      + 2.0*k_/omega_*(2.0*S & gradK_a)
      + 2.0*alpha_*(2.0*S & gradOmega_a)
    );
}


tmp<fvVectorMatrix> adjointkOmega::divDevRhoReff
(
    const volScalarField& rho,
    volVectorField& U
) const
{
    volScalarField muEff("muEff", rho*nuEff());

    return
    (
      - fvm::laplacian(muEff, U)
      - fvc::div(muEff*dev(T(fvc::grad(U))))
    );
}


bool adjointkOmega::read()
{
    if (RASModel::read())
    {
        Cmu_.readIfPresent(coeffDict());
        beta_.readIfPresent(coeffDict());
        alphaK_.readIfPresent(coeffDict());
        alphaOmega_.readIfPresent(coeffDict());

        return true;
    }
    else
    {
        return false;
    }
}


void adjointkOmega::correct()
{
    RASModel::correct();

    if (!turbulence_)
    {
        return;
    }

    //volScalarField G(GName(), nut_*2*magSqr(symm(fvc::grad(U_))));
    volScalarField nuEff_ = nu() + nut_;
    /*volScalarField*/ Par1 = (fvc::laplacian(nuEff_/nuEff_, U_)+fvc::div(nuEff_/nuEff_*dev(T(fvc::grad(U_))))) & U_a_;
    /*volScalarField*/ Par2 = alphaK_*fvc::laplacian(k_a_, k_);
    /*volScalarField*/ Par3 = alphaOmega_*fvc::laplacian(omega_a_, omega_);
    volScalarField Par = Par1 + Par2 + Par3;
    volSymmTensorField S = symm(fvc::grad(U_));
    volScalarField SS = magSqr(S);

    // Update omega and G at the wall
    //omega_a_.boundaryField().updateCoeffs();

    // Turbulence specific dissipation rate equation
    tmp<fvScalarMatrix> omegaEqn_a
    (
      //  fvm::ddt(omega_a_)
      - fvm::div(phi_, omega_a_)
      - fvm::laplacian(DomegaEff(), omega_a_)
     ==
      //  alpha_*G*omega_/k_
      //- fvm::Sp(beta_*omega_, omega_)
      - k_/sqr(omega_)*Par
      //- k_*k_a_*(2.0*SS/sqr(omega_)+Cmu_)
      //- 2.0*beta_*omega_*omega_a_
    );

    omegaEqn_a().relax();

    //omegaEqn_a().boundaryManipulate(omega_a_.boundaryField());

    solve(omegaEqn_a);
    //volScalarField omega_a_temp = -omega_a_;
    //bound(omega_a_temp, omegaMin_a_);
    //omega_a_ = -omega_a_temp;

    S1_c = fvc::div(phi_, omega_a_);
    S1_d = fvc::laplacian(DomegaEff(), omega_a_);


    // Turbulent kinetic energy equation
    tmp<fvScalarMatrix> kEqn_a
    (
      //  fvm::ddt(k_a_)
      - fvm::div(phi_, k_a_)
      - fvm::laplacian(DkEff(), k_a_)
     ==
      //  G
      //- fvm::Sp(Cmu_*omega_, k_)
        1.0/omega_*Par
      //+ (2.0*SS/omega_-Cmu_*omega_)*k_a_
    );

    kEqn_a().relax();
    solve(kEqn_a);
    //bound(k_a_, kMin_a_);

    S2_c = fvc::div(phi_, k_a_);
    S2_d = fvc::laplacian(DkEff(), k_a_);


    // Re-calculate viscosity
    //nut_ = k_/omega_;
    //nut_.correctBoundaryConditions();
}


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

} // End namespace RASModels
} // End namespace incompressible
} // End namespace Foam

// ************************************************************************* //
